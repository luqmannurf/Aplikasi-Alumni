<?php 
include "koneksi.php";
$kodeProdi = $_GET['id'];
$SQL = mysql_query("DELETE FROM t_jurusan WHERE prodiid = '$kodeProdi'") or die(mysql_error());
if ($SQL) {
	header('location:data-jurusan.php');
}
?>