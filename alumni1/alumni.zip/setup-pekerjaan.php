<?php
include "koneksi.php";
$npm = $_POST['cboNPM'];
$status = $_POST['cboStatus'];
$namaPerusahaan = $_POST['txtNamaPerusahaan'];
$alamatPerusahaan = $_POST['txtAlamatPerusahaan'];
$dept = $_POST['txtDept'];
$tanggalMasuk = $_POST['dtTanggalMasuk'];
$cekNPM=mysql_num_rows(mysql_query("SELECT npm FROM t_status_pekerjaan WHERE npm='$npm'"));
if ($cekNPM > 0) {
  echo "<script>window.alert('NPM Sudah di input');
		window.location=('tambah-pekerjaan.php')</script>";
} else {
$SQL = mysql_query("INSERT INTO t_status_pekerjaan VALUES('$npm', '$status', '$namaPerusahaan', '$alamatPerusahaan', '$dept', '$tanggalMasuk')") or die(mysql_error());
if ($SQL) {
	header('location:data-pekerjaan.php');
}
}
?>