<?php
include "koneksi.php";
$txtKodeProdi = $_POST['txtKodeProdi'];
$txtJenjang = $_POST['txtJenjang'];
$txtJurusan = $_POST['txtJurusan'];
$SQL = mysql_query("INSERT INTO t_jurusan VALUES('$txtKodeProdi', '$txtJenjang', '$txtJurusan')") or die(mysql_error());
if ($SQL) {
	header('location:data-jurusan.php');
}
?>