<?php include "header.php"; ?>
<?php include "menu.php"; ?>
<script type="text/javascript">
function validasi_input(form) {	
	if (form.cboJurusan.value =="0") {
		alert("Anda belum memilih Jurusan");
		return (false);
	}
		if (form.cboKodeSK.value =="0") {
		alert("Anda belum memilih Nomor SK");
		return (false);
	}
		return (true);
}
</script>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Data Alumni</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            .:: Tambah Alumni ::.
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
						<form role="form" action="setup-alumni.php" name="frmSetupAlumni" method="post" enctype="multipart/form-data"   onsubmit="return validasi_input(this)">
                                        <div class="form-group">
                                            <label>NPM</label>
                                            <input class="form-control" name="txtNPM" type="text" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input class="form-control" name="txtNama" type="text" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Jurusan</label>
                                            <?php
											include ("koneksi.php");
											echo '<select name="cboJurusan" class="form-control">';
											$SQL = mysql_query("SELECT * FROM t_jurusan ORDER BY prodiid");	            
											  echo '<option value="0">--Pilih--</option>';
											  while($tampilJurusan = mysql_fetch_array($SQL)) {
											  echo '<option value='.$tampilJurusan['prodiid'].'>'.$tampilJurusan['jurusan'].'</option>';
											  }
											echo '</select>';
											?>
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat</label>
                                            <textarea class="form-control" rows="3" name="txtAlamat" required></textarea>
                                        </div>
                                        <div class="control-group">
                						<label class="control-label" for="dtTanggalSK">Tanggal Lulus</label>
                						<div class="controls">
                   						<input id="dtTanggalLulus" type="text" class="form-control" name="dtTanggalLulus" required>
                						</div>
            							</div>
                                        <br>
                                        <div class="control-group">
                						<label class="control-label" for="dtTanggalWisuda">Tanggal Wisuda</label>
                						<div class="controls">
                   						<input id="dtTanggalWisuda" type="text" class="form-control" name="dtTanggalWisuda" required>
                						</div>
            							</div>
                                        <br>
                                        <div class="form-group">
                                            <label>No Telepon/HP</label>
                                            <input class="form-control" name="txtTelepon" type="text" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Ijazah</label>
                                            <input class="form-control" name="txtNoIjazah" type="text" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" name="txtEmail" type="email" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Scan Ijazah</label>
                                            <input type="file" name="txtScanIjazah" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Scan Transkrip Nilai (Lembar 1)</label>
                                            <input type="file" name="txtScanTranskrip1" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Scan Transkrip Nilai (Lembar 2)</label>
                                            <input type="file" name="txtScanTranskrip2" required >
                                        </div>
                                        <div class="form-group">
                                            <label>Foto</label>
                                            <input type="file" name="txtFoto" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor SK</label>
                                            <?php
											include ("koneksi.php");
											echo '<select name="cboKodeSK" class="form-control">';
											$SQL = mysql_query("SELECT * FROM t_kelulusan ORDER BY kd_sk");	            
											  echo '<option value="0">--Pilih--</option>';
											  while($tampilSK = mysql_fetch_array($SQL)) {
											  echo '<option value='.$tampilSK['kd_sk'].'>'.$tampilSK['no_sk'].'</option>';
											  }
											echo '</select>';
											?>
                                        </div>
                                        <hr>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                        <a href="data-alumni.php" class="btn btn-default">Batal</a>
                                    </form>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
    <script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
        <script>
            $(document).ready(function() {
                $("#dtTanggalLulus").datepicker();
            });
			
			$(document).ready(function() {
                $("#dtTanggalWisuda").datepicker();
            });
        </script>
</body>
</html>