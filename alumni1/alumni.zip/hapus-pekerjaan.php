<?php 
include "koneksi.php";
$npm = $_GET['id'];
$SQL = mysql_query("DELETE FROM t_status_pekerjaan WHERE npm = '$npm'") or die(mysql_error());
if ($SQL) {
	header('location:data-pekerjaan.php');
}
?>