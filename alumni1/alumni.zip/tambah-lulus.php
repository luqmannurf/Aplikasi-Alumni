<?php include "header.php"; ?>
<?php include "menu.php"; ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Tambah Data Kelulusan</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            .:: Tambah Kelulusan ::.
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="setup-lulus.php" name="input" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label>Kode SK</label>
                                            <input class="form-control" name="txtKodeSK" type="text" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor SK</label>
                                            <input class="form-control" name="txtNomorSK" type="text" required>
                                        </div>
                                        <div class="control-group">
                						<label class="control-label" for="dtTanggalSK">Tanggal SK</label>
                						<div class="controls">
                   						<input id="dtTanggalSK" type="text" class="form-control" name="dtTanggalSK" required>
                						</div>
            							</div>
                                        <br>
                                        <div class="control-group">
                						<label class="control-label" for="dtTanggalWisuda">Tanggal Wisuda</label>
                						<div class="controls">
                   						<input id="dtTanggalWisuda" type="text" class="form-control" name="dtTanggalWisuda" required>
                						</div>
            							</div>
                                        <br>
                                        <div class="form-group">
                                            <label>Scan SK</label>
                                            <input type="file" name="txtScanSK" required>
                                        </div>
                                        <hr>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                        <a href="data-lulus.php" class="btn btn-default">Batal</a>
                                    </form>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
    <script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
        <script>
            $(document).ready(function() {
                $("#dtTanggalSK").datepicker();
            });
			
			$(document).ready(function() {
                $("#dtTanggalWisuda").datepicker();
            });
        </script>
</body>
</html>