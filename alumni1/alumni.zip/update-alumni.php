<?php
include "koneksi.php";
$npm = $_POST['txtNPM'];
$nama = $_POST['txtNama'];
$jurusan = $_POST['cboJurusan'];
$alamat = $_POST['txtAlamat'];
$tanggalLulus = $_POST['dtTanggalLulus'];
$tanggalWisuda = $_POST['dtTanggalWisuda'];
$noTelepon = $_POST['txtTelepon'];
$noIjazah = $_POST['txtNoIjazah'];
$email = $_POST['txtEmail'];
$kodeSK = $_POST['cboKodeSK'];

#SQL untuk proses hapus gambar dalam folder
$SQLGambar = mysql_query("SELECT scan_ijazah, scan_transkrip_nilai_1, scan_transkrip_nilai_2, photo FROM t_alumni WHERE npm = '$npm'");
$dataGambar=mysql_fetch_array($SQLGambar);
###################################################################################
$scanIjazah = $_POST['txtNPM'].'_'.$_FILES['txtScanIjazah']['name'];
if (strlen($scanIjazah)>0) {
		if (is_uploaded_file($_FILES['txtScanIjazah']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanIjazah']['tmp_name'], "file-alumni/".$scanIjazah);
			if (empty($scanIjazah)) { //jika gambar kosong atau tidak di ganti
				mysql_query ("UPDATE t_alumni SET scan_ijazah='$scanIjazah' WHERE npm='$npm'");
			} elseif (!empty($scanIjazah)) { //jika gambar di ganti
				if (file_exists("file-alumni".'/'.$dataGambar['scan_ijazah'])) unlink("file-alumni".'/'.$dataGambar['scan_ijazah']);
				mysql_query("UPDATE t_alumni SET scan_ijazah='$scanIjazah' WHERE npm='$npm'");
			}
		}
	}
	
$scanTranskripNilai1 = $_POST['txtNPM'].'_'.$_FILES['txtScanTranskrip1']['name'];
if (strlen($scanTranskripNilai1)>0) {
		if (is_uploaded_file($_FILES['txtScanTranskrip1']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanTranskrip1']['tmp_name'], "file-alumni/".$scanTranskripNilai1);
			if (empty($scanTranskripNilai1)) { //jika gambar kosong atau tidak di ganti
				mysql_query ("UPDATE t_alumni SET scan_transkrip_nilai_1='$scanTranskripNilai1' WHERE npm='$npm'");
			} elseif (!empty($scanTranskripNilai1)) { //jika gambar di ganti
				if (file_exists("file-alumni".'/'.$dataGambar['scan_transkrip_nilai_1'])) unlink("file-alumni".'/'.$dataGambar['scan_transkrip_nilai_1']);
				mysql_query("UPDATE t_alumni SET scan_transkrip_nilai_1='$scanTranskripNilai1' WHERE npm='$npm'");
			}
		}
	}
	
$scanTranskripNilai2 = $_POST['txtNPM'].'_'.$_FILES['txtScanTranskrip2']['name'];
if (strlen($scanTranskripNilai2)>0) {
		if (is_uploaded_file($_FILES['txtScanTranskrip2']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanTranskrip2']['tmp_name'], "file-alumni/".$scanTranskripNilai2);
			if (empty($scanTranskripNilai2)) { //jika gambar kosong atau tidak di ganti
				mysql_query ("UPDATE t_alumni SET scan_transkrip_nilai_2='$scanTranskripNilai2' WHERE npm='$npm'");
			} elseif (!empty($scanTranskripNilai2)) { //jika gambar di ganti
				if (file_exists("file-alumni".'/'.$dataGambar['scan_transkrip_nilai_2'])) unlink("file-alumni".'/'.$dataGambar['scan_transkrip_nilai_2']);
				mysql_query("UPDATE t_alumni SET scan_transkrip_nilai_2='$scanTranskripNilai2' WHERE npm='$npm'");
			}
		}
	}
	
$foto = $_POST['txtNPM'].'_'.$_FILES['txtFoto']['name'];
if (strlen($foto)>0) {
		if (is_uploaded_file($_FILES['txtFoto']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtFoto']['tmp_name'], "file-alumni/".$foto);
			if (empty($foto)) { //jika gambar kosong atau tidak di ganti
				mysql_query ("UPDATE t_alumni SET photo='$foto' WHERE npm='$npm'");
			} elseif (!empty($foto)) { //jika gambar di ganti
				if (file_exists("file-alumni".'/'.$dataGambar['photo'])) unlink("file-alumni".'/'.$dataGambar['photo']);
				mysql_query("UPDATE t_alumni SET photo='$foto' WHERE npm='$npm'");
			}
		}
	}
mysql_query("UPDATE t_alumni SET nama='$nama', prodiID='$jurusan', alamat='$alamat', tanggal_lulus='$tanggalLulus', tanggal_wisuda='$tanggalWisuda', no_hp='$noTelepon', no_ijazah='$noIjazah', email='$email', kd_sk='$kodeSK' WHERE npm='$npm'");
header('location:data-alumni.php');
?>