<?php include "header.php"; ?>
<?php include "menu.php"; ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Home</h1>
                </div>
            </div>
            <div class="row">
            </div>
            <div class="row">
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            .:: Home ::.
                        </div>
                        <div class="panel-body">
                            <div class="panel-group" id="accordion">
                                        <div class="panel-body">
                                             Sistem adalah suatu kumpulan atau himpunan dari unsur, komponen, atau variabel-variabel yang terorganisasi, saling berinteraksi, saling tergantung satu sama lain dan terpadu. Suatu sistem adalah terdiri dari manusia (mereka yang memakai komputer) dan prosedur-prosedur (petunjuk manusia ikuti dalam melaksanakan tugas-tugas mereka). Dari defenisi ini dapat dirinci lebih lanjut pengertian sistem secara umum, yaitu:

    Setiap sistem terdiri dari unsur-unsur
    Unsur-unsur tersebut merupakan bagian terpadu sistem yang bersangkutan
    Unsur sistem tersebut bekerja sama untuk mencapai tujuan sistem.
    Suatu sistem merupakan bagian dari sistem lain yang lebih besar.<p><br>

Karakteristik Sistem

Suatu sistem mempunyai karakteristik sistem atau sifat tertentu, yaitu:

    Komponen Sistem

    Komponen sistem suatu sistem terdiri dari sejumlah komponen yang saling berinteraksi, yang artinya saling bekerja sama membentuk suatu kesatuan.
    second list item, Lorem ipsum dolor sit amet, consete
    third list item, Lorem ipsum dolor sit amet, consete
    fourth list item, Lorem ipsum dolor sit amet, consete<p><br>

Definisi sistem informasi adalah suatu sistem dalam suatu organisasi yang mempertemukan kebutuhan pengolahan transaksi harian yang mendukung fungsi operasi organisasi yang bersifat manajerial dengan kegiatan strategi dari suatu organisasi untuk dapat menyediakan kepada pihak luar tertentu dengan informasi yang diperlukan untuk pengambilan keputusan. Sistem informasi dalam suatu organisasi dapat dikatakan sebagai suatu sistem yang menyediakan informasi bagi semua tingkatan dalam organisasi tersebut kapan saja diperlukan. Sistem ini menyimpan, mengambil, mengubah, mengolah dan mengkomunikasikan informasi yang diterima dengan menggunakan sistem informasi atau peralatan sistem lainnya.
                                        </div>
                                    </div>
                                </div>
                                
                                        
                                    </div>
                                </div>
                                
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
            </div>
            <div class="row">
            </div>
            <div class="row">
            </div>
        </div>
    </div>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
</body>
</html>