<?php 
include "koneksi.php";
$kodeSK = $_GET['id'];
$SQLGambar = mysql_query("SELECT scan_sk FROM t_kelulusan WHERE kd_sk = '$kodeSK'");
$dataGambar=mysql_fetch_array($SQLGambar);
if (file_exists("file-alumni".'/'.$dataGambar['scan_sk'])) unlink("file-alumni".'/'.$dataGambar['scan_sk']);
$SQL = mysql_query("DELETE FROM t_kelulusan WHERE kd_sk = '$kodeSK'") or die(mysql_error());
if ($SQL) {
	header('location:data-lulus.php');
}

?>