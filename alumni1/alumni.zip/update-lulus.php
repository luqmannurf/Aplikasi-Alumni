<?php
include "koneksi.php";
$kodeSK = $_POST['txtKodeSK'];
$nomorSK = $_POST['txtNomorSK'];
$tanggalSK = $_POST['dtTanggalSK'];
$tanggalWisuda = $_POST['dtTanggalWisuda'];

#SQL untuk proses hapus gambar dalam folder
$SQLGambar = mysql_query("SELECT scan_sk FROM t_kelulusan WHERE kd_sk = '$kodeSK'");
$dataGambar=mysql_fetch_array($SQLGambar);
###################################################################################
$scanSK = $_POST['txtKodeSK'].'_'.$_FILES['txtScanSK']['name'];
if (strlen($scanSK)>0) {
		if (is_uploaded_file($_FILES['txtScanSK']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanSK']['tmp_name'], "file-alumni/".$scanSK);
			if (empty($scanSK)) { //jika gambar kosong atau tidak di ganti
				mysql_query ("UPDATE t_kelulusan SET scan_sk='$scanSK' WHERE kd_sk='$kodeSK'");
			} elseif (!empty($scanSK)) { //jika gambar di ganti
				if (file_exists("file-alumni".'/'.$dataGambar['scan_sk'])) unlink("file-alumni".'/'.$dataGambar['scan_sk']);
				mysql_query("UPDATE t_kelulusan SET no_sk='$nomorSK', tanggal_sk='$tanggalSK', tanggal_wisuda='$tanggalWisuda', scan_sk='$scanSK' WHERE kd_sk='$kodeSK'");
			}
		}
	}
header('location:data-lulus.php');
?>