<nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="input-group custom-search-form">
                            
                            <span class="input-group-btn">
                                
                                    <i class="fa fa-search"></i>
                                
                            </span>
                        </div>
                        <!-- Menu -->
                    </li>
                    <li>
                        <a href="./">»<i class="fa fa-home fa-fw"></i> Beranda</a>
                    </li>
					<li>
						<a href="data-jurusan.php">»<i class="fa fa-filter fa-fw"></i> Data Jurusan</a>
					</li>
                    <li>
                        <a href="data-lulus.php">»<i class="fa fa-plane fa-fw"></i> Data Kelulusan</a>
                    </li>
                    <li>
                        <a href="data-alumni.php">»<i class="fa fa-book fa-fw"></i> Data Alumni</a>
                    </li>
                    <li>
						<a href="data-pekerjaan.php">»<i class="fa fa-shopping-cart fa-fw"></i> Data Pekerjaan</a>
					</li>
                    <li>
                        <a href="laporan.php">»<i class="fa fa-print fa-fw"></i> Laporan</a>
                    </li>
                    <li>
                        <a href="javascript:if(confirm('Keluar panel admin ?')) { document.location='logout.php'; }">»<i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </nav>