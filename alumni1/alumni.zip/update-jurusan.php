<?php
include "koneksi.php";
$kodeProdi = $_POST['txtKodeProdi'];
$jenjang = $_POST['txtJenjang'];
$jurusan= $_POST['txtJurusan'];
$SQL = mysql_query("UPDATE t_jurusan SET jenjang='$jenjang', jurusan='$jurusan' WHERE prodiid='$kodeProdi'") or die(mysql_error());
if ($SQL) {
	header('location:data-jurusan.php');
}
?>