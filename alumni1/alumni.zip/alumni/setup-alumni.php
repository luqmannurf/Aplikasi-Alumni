<?php
include "koneksi.php";
$npm = $_POST['txtNPM'];
$nama = $_POST['txtNama'];
$jurusan = $_POST['cboJurusan'];
$alamat = $_POST['txtAlamat'];
$tanggalLulus = $_POST['dtTanggalLulus'];
$tanggalWisuda = $_POST['dtTanggalWisuda'];
$noTelepon = $_POST['txtTelepon'];
$noIjazah = $_POST['txtNoIjazah'];
$email = $_POST['txtEmail'];

$scanIjazah = $_POST['txtNPM'].'_'.$_FILES['txtScanIjazah']['name'];
if (strlen($scanIjazah)>0) {
		if (is_uploaded_file($_FILES['txtScanIjazah']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanIjazah']['tmp_name'], "file-alumni/".$scanIjazah);
		}
	}

$scanTranskrip1 = $_POST['txtNPM'].'_'.$_FILES['txtScanTranskrip1']['name'];
if (strlen($scanTranskrip1)>0) {
		if (is_uploaded_file($_FILES['txtScanTranskrip1']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanTranskrip1']['tmp_name'], "file-alumni/".$scanTranskrip1);
		}
	}

$scanTranskrip2 = $_POST['txtNPM'].'_'.$_FILES['txtScanTranskrip2']['name'];
if (strlen($scanTranskrip2)>0) {
		if (is_uploaded_file($_FILES['txtScanTranskrip2']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanTranskrip2']['tmp_name'], "file-alumni/".$scanTranskrip2);
		}
	}
	
$foto = $_POST['txtNPM'].'_'.$_FILES['txtFoto']['name'];
if (strlen($foto)>0) {
		if (is_uploaded_file($_FILES['txtFoto']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtFoto']['tmp_name'], "file-alumni/".$foto);
		}
	}

$kodeSK = $_POST['cboKodeSK'];

$SQL = mysql_query("INSERT INTO t_alumni VALUES('$npm', '$nama', '$jurusan', '$alamat', '$tanggalLulus', '$tanggalWisuda', '$noTelepon', '$noIjazah', '$email', '$scanIjazah', '$scanTranskrip1', '$scanTranskrip2', '$foto', '$kodeSK')") or die(mysql_error());
if ($SQL) {
	header('location:data-alumni.php');
}
?>