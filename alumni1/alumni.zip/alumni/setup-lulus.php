<?php
include "koneksi.php";
$kodeSK = $_POST['txtKodeSK'];
$nomorSK = $_POST['txtNomorSK'];
$tanggalSK = $_POST['dtTanggalSK'];
$tanggalWisuda = $_POST['dtTanggalWisuda'];

$scanSK = $_POST['txtKodeSK'].'_'.$_FILES['txtScanSK']['name'];
if (strlen($scanSK)>0) {
		if (is_uploaded_file($_FILES['txtScanSK']['tmp_name'])) {
			move_uploaded_file ($_FILES['txtScanSK']['tmp_name'], "file-alumni/".$scanSK);
		}
	}
	
$SQL = mysql_query("INSERT INTO t_kelulusan VALUES('$kodeSK', '$nomorSK', '$tanggalSK', '$tanggalWisuda', '$scanSK')") or die(mysql_error());
if ($SQL) {
	header('location:data-lulus.php');
}
?>