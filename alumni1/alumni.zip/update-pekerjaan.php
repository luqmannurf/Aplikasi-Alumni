<?php
include "koneksi.php";
$npm = $_POST['txtNPM'];
$status = $_POST['cboStatus'];
$namaPerusahaan = $_POST['txtNamaPerusahaan'];
$alamatPerusahaan = $_POST['txtAlamatPerusahaan'];
$dept = $_POST['txtDept'];
$tanggalMasuk = $_POST['dtTanggalMasuk'];

$SQL = mysql_query("UPDATE t_status_pekerjaan SET status_pekerjaan='$status', nama_pt='$namaPerusahaan', alamat_pt='$alamatPerusahaan', departemen='$dept',
mulai_bekerja='$tanggalMasuk' WHERE npm='$npm'") or die(mysql_error());
if ($SQL) {
	header('location:data-pekerjaan.php');
}
?>