<?php include "header.php"; ?>
<?php include "menu.php"; ?>
<script type="text/javascript">
function validasi_input(form) {	
	if (form.cboStatus.value =="0") {
		alert("Anda belum memilih status pekerjaan");
		return (false);
	}
		return (true);
}
</script>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Ubah Pekerjaan Alumni</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            .:: Ubah Pekerjaan Alumni ::.
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                <?php
								$npm=$_GET['id'];
								$SQL=mysql_query("SELECT * FROM t_status_pekerjaan WHERE npm='$npm'");
								$data=mysql_fetch_array($SQL);
								?>
                                    <form role="form" action="update-pekerjaan.php" name="frmUpdatePekerjaan" method="post" onsubmit="return validasi_input(this)">
                                        <div class="form-group">
                                            <label>NPM</label>
                                            <input class="form-control" name="txtNPM" type="text" required value="<?php echo $data['npm']; ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Status Pekerjaan</label>
                                            <select class="form-control" name="cboStatus">
                                            <option value="0">--Pilih--</option>
                                                <option value="Sudah Bekerja">Sudah Bekerja</option>
                                                <option value="Belum Bekerja">Belum Bekerja</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Perusahaan</label>
                                            <input class="form-control" name="txtNamaPerusahaan" type="text" value="<?php echo $data['nama_pt']; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Alamat Perusahaan</label>
                                            <textarea class="form-control" rows="3" name="txtAlamatPerusahaan"><?php echo $data['alamat_pt']; ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Department</label>
                                            <input class="form-control" name="txtDept" type="text" value="<?php echo $data['departemen']; ?>">
                                        </div>
                                        <div class="control-group">
                						<label class="control-label" for="dtTanggalMasuk">Tanggal Masuk</label>
                						<div class="controls">
                   						<input id="dtTanggalMasuk" type="text" class="form-control" name="dtTanggalMasuk" value="<?php echo $data['mulai_bekerja']; ?>">
                						</div>
            							</div>
                                        <br>
                                        <hr>
                                        <button type="submit" class="btn btn-primary">Update</button>
                                        <a href="data-pekerjaan.php" class="btn btn-default">Batal</a>
                                    </form>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
    <script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-datepicker.min.js"></script>
        <script>
            $(document).ready(function() {
                $("#dtTanggalMasuk").datepicker();
            });
        </script>
</body>
</html>